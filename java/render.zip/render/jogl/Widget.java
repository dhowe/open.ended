package render.jogl;
import java.awt.*;
import java.awt.event.*;
/* GENERIC WIDGET */

public class Widget extends Rectangle implements MouseListener, MouseMotionListener
{
   public Color bgColor = new Color(255,230,230,255), fgColor = Color.black;

   protected boolean isDown = false;

//---------------- OBJECT CONSTRUCTOR

   public Widget(int x, int y, int width, int height) {
	  super(x, y, width, height);
   }

//---------------- HANDLING MOUSE EVENTS

   public boolean down(int x, int y) {     // DOWN EVENT
	  return isDown = inside(x,y);
   }
   public boolean drag(int x, int y) {     // DRAG EVENT
	  return isDown;
   }
   public boolean up(int x, int y) {       // UP EVENT
	  if (isDown) {
		 isDown = false;
		 return true;          // IF WAS DOWN, THEN RETURN TRUE
	  }
	  return false;            // OTHERWISE, RETURN FALSE
   }
   
   public void mouseEntered(MouseEvent e) {
   }
	
   public void mouseExited(MouseEvent e) {
   }


   public void mousePressed(MouseEvent e) {
   		down(e.getX(),e.getY());
   }
    
   public void mouseReleased(MouseEvent e) {
   		up(e.getX(),e.getY());
   }
    
   public void mouseClicked(MouseEvent e) {
   }

   public void mouseDragged(MouseEvent e) {
	  drag(e.getX(),e.getY());
   }
    
   public void mouseMoved(MouseEvent e) {
   }


//---------------- RENDERING THE WIDGET

   public void render(Graphics g) {
	  g.setColor(bgColor);
	  g.fill3DRect(x, y, width, height, true);
   }
}
