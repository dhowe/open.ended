package render.jogl;

import java.awt.*;

public class Button extends Widget
{
   public String[] labels = {"BUTTON"};
   private int value = 0;
   
//---------------- OBJECT CONSTRUCTOR

   public Button(int x, int y, int width, int height) {
	  super(x, y, width, height);
   }

//---------------- GET A VALUE

   public void setValue(int n) { value = n; }
   public int getValue() { return value; }

//---------------- HANDLING MOUSE EVENTS

   public boolean up(int x, int y) {       // UP EVENT
	  if (super.up(x,y)) {
		 if (inside(x,y))
			value = (value + 1) % labels.length;
		 return true;
	  }
	  return false;
   }
   
//---------------- RENDERING THE WIDGET

   public void render(Graphics g) {
   	  
	  g.setColor(bgColor);
	 // g.fill3DRect(x, y, width, height, ! isDown);
	  if (!isDown) {
	  	int r = bgColor.getRed()-50;
	  	if (r<0) r = 0;
		int gr = bgColor.getGreen()-50;
		if (gr<0) gr = 0;
		int b = bgColor.getBlue()-50;
		if (b<0) b = 0;
	  	
	  	Color color = new Color(r,gr,b,255);
	  	g.setColor(color);
	  	g.drawRect(x,y,width,height);
	  	g.setColor(bgColor);
	  	g.fillRect(x,y,width-1,height-1);
	  } else {
	  int r = bgColor.getRed()-50;
	  if (r<0) r = 0;
	  int gr = bgColor.getGreen()-50;
	  if (gr<0) gr = 0;
	  int b = bgColor.getBlue()-50;
	  if (b<0) b = 0;
	  	
	  Color color = new Color(r,gr,b);
	  //g.setColor(color);
	  g.drawRect(x,y,width,height);
	  g.setColor(color);
	  g.fillRect(x+1,y+1,width-1,height-1);
	}

	  g.setColor(fgColor);
	  g.drawString(labels[value], x+2, y+12);
   }
}
